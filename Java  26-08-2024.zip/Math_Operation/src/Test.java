class add {
	int a,b,c;
	
	public void addition() {
		
        a=10;
		b=5;
		c=a+b;
		
		System.out.println(c);
	}
	
	public void multi() {
	 a=10;
	 b=5; 
	 c=a*b;
	 System.out.println(c);
					
	}
	
	public void addition(int d,int e) {
		a=d;
		b=e;
		c=a+b;
		System.out.println(c);
		
	}
}
public class Test {

	public static void main(String[] args) {
		
		add a1= new add();
		add a2= new add();

		
		a1.addition();
		a1.addition(10, 0);
		a2.multi();
		
		
	}
}
