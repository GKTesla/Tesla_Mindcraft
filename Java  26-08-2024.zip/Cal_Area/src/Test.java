

class shape{
	int a;
	double p = 3.14;
	
	public void area(int l,int b){
		 
		l= 10;
		b= 20;
		a=l*b;
			
       	System.out.println(a);     		
	}
	public void area(int l) {
		
		a= l*l;
		System.out.println(a);
	}
	public void area(double r){ 
		a = p*r*r;
	    System.out.println(a);		
	}	
}	


public class Test {

	public static void main(String[] args) {
		
		shape s1 = new shape();
		
		s1.area(5, 10);
		s1.area(10);
		s1.area(10);
		
	}
}
