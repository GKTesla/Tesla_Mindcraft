class fib {
	
	int a=0,b=1,n=20,i;
	 
	 public void fibseries() {
		 System.out.println(a + " ");
		 if (n<1)
			 return;
		 for (i=1;i<n;i++) {
			 
			 System.out.println(a + " ");
			 int c = a+b;
			 a=b;
			 b=c; 
					 
		 }
			
	 }
	 	 	
}


public class test {

	public static void main(String[] args) {
		
		fib f1= new fib();
		
		f1.fibseries();
		
	}

}

