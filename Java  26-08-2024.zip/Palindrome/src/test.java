class pali  {
	int a = 434,b= 0,c;
	int d= a;
	
	
	
public void function() { 	
	while (a != 0) {
		c = a%10;
		b= b*10 + c;
		a /= 10;
					
	}
	if (a==b) {
		System.out.println(a+ "is palindrome");	
			}
	else {
		System.out.println(a+ "is not a palinndrome");
	}
}
}
public class test {

	public static void main(String[] args) {
		
		pali p1 = new pali();
	    p1.function();
		

	}
}


