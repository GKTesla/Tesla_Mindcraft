import java.util.Scanner;

class Employee{

	int salary,emp_id,bonus,total;
	String name, dept;
	
	public void Data() {
		System.out.println("Enter Employee Name: ");
		Scanner sc = new Scanner(System.in);
		name = sc.next();
		System.out.println("Enter Emp Code: ");
		emp_id = sc.nextInt();
		System.out.println("Enter Department: ");
		dept = sc.next();
		System.out.println("Enter Salary: ");
		salary = sc.nextInt();
		
		System.out.println("Name: "+ name);
		System.out.println("Emp_id: "+ emp_id);
		System.out.println("Department: "+ dept);
		System.out.println("Salary: "+ salary);

		if((salary>1000) && (salary<1500)) {
			bonus = salary*10/100;
			total = salary + bonus;
			System.out.println("Salary is incremented by 10%: "+ total);
		}
		else if(salary>1500) {
			bonus = salary*15/100;
			total = salary + bonus;
			System.out.println("Salary is incremented by 15% "+ total);
		}
		else {
			System.out.println("Salary is not incremented.");
		}
	}
}

public class test {

	public static void main(String[] args) {
		
		Employee fun = new Employee();
		fun.Data();
	}

}