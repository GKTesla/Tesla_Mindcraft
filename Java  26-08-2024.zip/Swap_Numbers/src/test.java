class swap {
	int a=15,b=20,c;
	
	
	public void function() {
		System.out.println("After Swap a = " +a+ " b = " +b );
		c=a;
		a=b;
		b=c;

		System.out.println("After Swap a = " +a+ " b = " +b );
		}
}


public class test {

	public static void main(String[] args) {
		
		swap s1 = new swap();
	    s1.function();
	}
		
	}


